/*
Grupo:
Rafael Souza 
Paulo Kenji Souza IIyama
*/

const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

// Endpoints REST
app.get('/', (req, res) => {
    res.send('Rafael Souza e Paulo Kenji');
});

app.get('/api/data', (req, res) => {
    res.json({ message: 'Aqui estão os dados' });
});

app.post('/api/data', (req, res) => {
    const newData = req.body;
    res.json({ message: 'Dados recebidos', data: newData });
});

app.listen(port, () => {
    console.log(`Servidor REST rodando em http://localhost:${port}`);
});
